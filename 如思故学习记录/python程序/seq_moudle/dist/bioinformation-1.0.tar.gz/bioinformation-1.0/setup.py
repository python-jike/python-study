from distutils.core import setup
#name 模块名称
#version 版本号
#description 描述
#author 作者
#py.modules 要发布的内容
setup(name='bioinformation',version='1.0',description='处理生信数据，暂时只能够用于做基因家族分析所用到的数据处理',
author='如思故',py_modules=['seq_module'])